'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import styles from '../styles/Hero.module.css';

const slides = [
  {
    title: 'Empowering Future Leaders',
    subtitle: 'Expert coaching for grades 7–12. Build strong foundations, achieve extraordinary results.',
    bg: 'linear-gradient(135deg, #1e40af 0%, #3b82f6 100%)',
    emoji: '🎓',
  },
  {
    title: 'Excellence in Every Subject',
    subtitle: 'Science, Maths, Commerce & Arts — our experienced faculty ensures holistic academic growth.',
    bg: 'linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%)',
    emoji: '📚',
  },
  {
    title: 'Your Success, Our Mission',
    subtitle: 'Thousands of students have achieved top marks with Gurukul Eduworld. Join them today.',
    bg: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 100%)',
    emoji: '🏆',
  },
];

export default function HeroCarousel() {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent(c => (c + 1) % slides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const slide = slides[current];

  return (
    <section className={styles.hero} style={{ background: slide.bg }}>
      <div className={styles.overlay} />
      <div className={`container ${styles.content}`}>
        <div className={styles.emoji}>{slide.emoji}</div>
        <h1 className={styles.title}>{slide.title}</h1>
        <p className={styles.subtitle}>{slide.subtitle}</p>
        <div className={styles.actions}>
          <Link href="/classes/9th" className={styles.btnWhite}>View Courses</Link>
          <Link href="/about#contact" className={styles.btnOutlineWhite}>Contact Us</Link>
        </div>
        <div className={styles.dots}>
          {slides.map((_, i) => (
            <button
              key={i}
              className={`${styles.dot} ${i === current ? styles.activeDot : ''}`}
              onClick={() => setCurrent(i)}
              aria-label={`Slide ${i + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}