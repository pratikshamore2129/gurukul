import Link from 'next/link';
import styles from '../styles/Footer.module.css';

const grades = ['7th','8th','9th','10th','11th','12th'];

export default function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.inner}`}>
        <div className={styles.col}>
          <div className={styles.logoWrap}>
            <div className={styles.logoIcon}>GE</div>
            <div>
              <strong>Gurukul Eduworld</strong>
              <span>Excellence in Education</span>
            </div>
          </div>
          <p className={styles.bio}>
            Empowering students of grades 7–12 with expert coaching, structured curriculum, 
            and personal attention since 2010.
          </p>
          <div className={styles.socials}>
            {['📘 Facebook','📸 Instagram','🐦 Twitter','▶️ YouTube'].map(s => (
              <a key={s} href="#" className={styles.social}>{s}</a>
            ))}
          </div>
        </div>

        <div className={styles.col}>
          <h4>Quick Links</h4>
          <ul>
            <li><Link href="/">Home</Link></li>
            <li><Link href="/about">About Us</Link></li>
            <li><Link href="/blog">Blog</Link></li>
            <li><Link href="/faq">FAQ</Link></li>
            <li><Link href="/about#contact">Contact</Link></li>
          </ul>
        </div>

        <div className={styles.col}>
          <h4>Classes</h4>
          <ul>
            {grades.map(g => (
              <li key={g}><Link href={`/classes/${g.toLowerCase()}`}>Class {g}</Link></li>
            ))}
          </ul>
        </div>

        <div className={styles.col}>
          <h4>Contact Us</h4>
          <p>📍 123 Education Lane, Mumbai, MH 400001</p>
          <p>📞 +91 98765 43210</p>
          <p>✉️ info@gurukuleduworld.com</p>
          <p>🕐 Mon–Sat: 7 AM – 8 PM</p>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} Gurukul Eduworld. All rights reserved.</p>
      </div>
    </footer>
  );
}