'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import styles from '../styles/Navbar.module.css';

const grades = ['7th', '8th', '9th', '10th', '11th', '12th'];

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <nav className={`${styles.navbar} ${scrolled ? styles.scrolled : ''}`}>
      <div className={`container ${styles.inner}`}>
        {/* Logo */}
        <Link href="/" className={styles.logo}>
          <div className={styles.logoIcon}>GE</div>
          <div>
            <span className={styles.logoMain}>Gurukul</span>
            <span className={styles.logoSub}>Eduworld</span>
          </div>
        </Link>

        {/* Desktop Nav */}
        <ul className={styles.navLinks}>
          <li><Link href="/">Home</Link></li>
          <li><Link href="/about">About</Link></li>
          <li
            className={styles.dropdown}
            onMouseEnter={() => setDropdownOpen(true)}
            onMouseLeave={() => setDropdownOpen(false)}
          >
            <span>Classes ▾</span>
            {dropdownOpen && (
              <ul className={styles.dropdownMenu}>
                {grades.map(g => (
                  <li key={g}>
                    <Link href={`/classes/${g.toLowerCase()}`}>Class {g}</Link>
                  </li>
                ))}
              </ul>
            )}
          </li>
          <li><Link href="/blog">Blog</Link></li>
          <li><Link href="/faq">FAQ</Link></li>
        </ul>

        <Link href="/about#contact" className="btn-primary">Join Now</Link>

        {/* Hamburger */}
        <button
          className={styles.hamburger}
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle menu"
        >
          <span /><span /><span />
        </button>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className={styles.mobileMenu}>
          <Link href="/" onClick={() => setMenuOpen(false)}>Home</Link>
          <Link href="/about" onClick={() => setMenuOpen(false)}>About</Link>
          <div className={styles.mobileDropdown}>
            <strong>Classes</strong>
            {grades.map(g => (
              <Link key={g} href={`/classes/${g.toLowerCase()}`} onClick={() => setMenuOpen(false)}>
                Class {g}
              </Link>
            ))}
          </div>
          <Link href="/blog" onClick={() => setMenuOpen(false)}>Blog</Link>
          <Link href="/faq" onClick={() => setMenuOpen(false)}>FAQ</Link>
          <Link href="/about#contact" className="btn-primary" onClick={() => setMenuOpen(false)}>Join Now</Link>
        </div>
      )}
    </nav>
  );
}