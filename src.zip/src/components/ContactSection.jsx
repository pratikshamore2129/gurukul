'use client';
import { useState } from 'react';
import styles from '../styles/Home.module.css';

export default function ContactSection() {
  const [form, setForm] = useState({ name: '', phone: '', grade: '', message: '' });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = e => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 4000);
    setForm({ name: '', phone: '', grade: '', message: '' });
  };

  return (
    <section className={`section ${styles.contactSection}`} id="contact">
      <div className="container">
        <h2 className="section-title" style={{ textAlign: 'center' }}>Get in Touch</h2>
<p className="section-subtitle" style={{ textAlign: 'center' }}>
  {"Ready to start your academic journey? We'd love to hear from you."}
</p>
        <div className={styles.contactGrid}>
          {/* Left: Info */}
          <div className={styles.contactInfo}>
            <div className={styles.contactItem}>
              <div className={styles.contactIcon}>📍</div>
              <div>
                <strong>Address</strong>
                <p>123 Education Lane, Knowledge Park, Mumbai, Maharashtra - 400001</p>
              </div>
            </div>
            <div className={styles.contactItem}>
              <div className={styles.contactIcon}>📞</div>
              <div>
                <strong>Phone</strong>
                <p>+91 98765 43210</p>
                <p>+91 91234 56789</p>
              </div>
            </div>
            <div className={styles.contactItem}>
              <div className={styles.contactIcon}>✉️</div>
              <div>
                <strong>Email</strong>
                <p>info@gurukuleduworld.com</p>
              </div>
            </div>
            <div className={styles.contactItem}>
              <div className={styles.contactIcon}>🕐</div>
              <div>
                <strong>Hours</strong>
                <p>Mon–Sat: 7:00 AM – 8:00 PM</p>
                <p>Sun: 9:00 AM – 1:00 PM</p>
              </div>
            </div>
            <div className={styles.mapEmbed}>
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d241317.11609823277!2d72.74109995709657!3d19.08219783958221!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c6306644edc1%3A0x5da4ed8f8d648c69!2sMumbai%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1710000000000"
                width="100%"
                height="200"
                style={{ border: 0, borderRadius: '10px' }}
                allowFullScreen
                loading="lazy"
                title="Location"
              />
            </div>
          </div>

          {/* Right: Form */}
          <div className={styles.contactForm}>
            <h3>Enquire Now</h3>
         {submitted && (
  <div className={styles.successMsg}>
    ✅ Thank you! {"We'll contact you soon."}
  </div>
)}
            <form onSubmit={handleSubmit}>
              <div className={styles.formGroup}>
                <label>Full Name *</label>
                <input
                  type="text"
                  name="name"
                  placeholder="Your full name"
                  value={form.name}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className={styles.formGroup}>
                <label>Phone Number *</label>
                <input
                  type="tel"
                  name="phone"
                  placeholder="+91 XXXXX XXXXX"
                  value={form.phone}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className={styles.formGroup}>
                <label>Interested Grade</label>
                <select name="grade" value={form.grade} onChange={handleChange}>
                  <option value="">Select Grade</option>
                  {['7th','8th','9th','10th','11th','12th'].map(g => (
                    <option key={g} value={g}>Class {g}</option>
                  ))}
                </select>
              </div>
              <div className={styles.formGroup}>
                <label>Message</label>
                <textarea
                  name="message"
                  rows="4"
                  placeholder="Any specific queries or subjects of interest..."
                  value={form.message}
                  onChange={handleChange}
                />
              </div>
              <button type="submit" className="btn-primary" style={{ width: '100%' }}>
                Send Enquiry
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}