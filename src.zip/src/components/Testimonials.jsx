import styles from '../styles/Home.module.css';

const testimonials = [
  { name: 'Ananya Sharma', grade: 'Class 12', text: 'Gurukul Eduworld transformed my understanding of Physics and Maths. I scored 94% in boards!', initials: 'AS' },
  { name: 'Rohan Patel', grade: 'Class 10', text: 'The teachers are incredibly supportive and always available for doubts. Best institute ever!', initials: 'RP' },
  { name: 'Priya Mehta', grade: 'Class 11', text: 'Regular tests and personal attention helped me improve from 65% to 89%. Highly recommended!', initials: 'PM' },
  { name: 'Arjun Singh', grade: 'Class 9', text: 'The study material and mock tests are top-notch. My confidence has grown tremendously.', initials: 'AS' },
  { name: 'Sneha Joshi', grade: 'Class 12', text: 'Got into my dream engineering college thanks to the structured preparation at Gurukul Eduworld.', initials: 'SJ' },
  { name: 'Vikram Rao', grade: 'Class 8', text: 'Even at Class 8, the foundation they build is exceptional. My son loves going to class!', initials: 'VR' },
];

export default function Testimonials() {
  return (
    <section className={`section ${styles.testimonialSection}`}>
      <div className="container">
        <h2 className="section-title" style={{ textAlign: 'center' }}>What Students Say</h2>
        <p className="section-subtitle" style={{ textAlign: 'center' }}>
          Real stories from real students who transformed their academic journey
        </p>
        <div className={styles.testimonialsGrid}>
          {testimonials.map((t, i) => (
            <div key={i} className={styles.testimonialCard}>
              <div className={styles.stars}>★★★★★</div>
          <p className={styles.testimonialText}>
          “{t.text}”
             </p>
              <div className={styles.testimonialAuthor}>
                <div className={styles.avatar}>{t.initials}</div>
                <div>
                  <strong>{t.name}</strong>
                  <span>{t.grade}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}