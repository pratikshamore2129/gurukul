import Navbar from '../components/Navbar';
import HeroCarousel from '../components/HeroCarousel';
import Testimonials from '../components/Testimonials';
import OurStory from '../components/OurStory';
import ContactSection from '../components/ContactSection';
import Footer from '../components/Footer';
import styles from '../styles/Home.module.css';
import Link from 'next/link';

export const metadata = {
  title: 'Gurukul Eduworld | Premier Coaching for Grades 7–12',
  description: 'Expert coaching for 7th to 12th standard students. Join Gurukul Eduworld today.',
};

export default function HomePage() {
  return (
    <>
      <Navbar />
      <main>
        <HeroCarousel />

        {/* About Strip */}
        <section className={`section ${styles.aboutStrip}`}>
          <div className="container">
            <div className={styles.aboutGrid}>
              <div className={styles.aboutImageBox}>🏫</div>
              <div className={styles.aboutText}>
                <span className={styles.aboutBadge}>About Us</span>
                <h2>{"Building Tomorrow's Leaders Since 2010"}</h2>
                <p>
                  Gurukul Eduworld is a premier coaching institute dedicated to students in grades 7–12. 
                  Our experienced faculty, structured curriculum, and personalised attention ensure 
                  every student reaches their full potential.
                </p>
                <p>
                  From foundation subjects in middle school to board exam preparation and competitive 
                  entrance coaching, we provide comprehensive academic support at every stage.
                </p>
                <div className={styles.statRow}>
                  <div className={styles.stat}>
                    <strong>5000+</strong>
                    <span>Students Taught</span>
                  </div>
                  <div className={styles.stat}>
                    <strong>95%</strong>
                    <span>Success Rate</span>
                  </div>
                  <div className={styles.stat}>
                    <strong>14+</strong>
                    <span>Years of Excellence</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <Testimonials />
        <OurStory />
        <ContactSection />
      </main>
      <Footer />
    </>
  );
}