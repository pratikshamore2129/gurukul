import Navbar from '../../../components/Navbar';
import Footer from '../../../components/Footer';
import ContactSection from '../../../components/ContactSection';
import styles from '../../../styles/Classes.module.css';
import { notFound } from 'next/navigation';

const gradeData = {
  '7th': {
    title: 'Class 7th',
    tagline: 'Building Strong Foundations',
    desc: 'Class 7 is where curiosity meets structured learning. We help students develop strong conceptual foundations in all core subjects.',
    subjects: ['Mathematics', 'Science', 'Social Studies', 'English', 'Hindi'],
    highlights: ['Concept-first approach', 'Interactive activities', 'Weekly tests', 'Parent progress reports'],
    emoji: '🌱',
  },
  '8th': {
    title: 'Class 8th',
    tagline: 'Expanding Horizons',
    desc: 'Class 8 introduces more complex topics. We ensure students understand advanced concepts in Maths and Science while building analytical skills.',
    subjects: ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English', 'Social Studies'],
    highlights: ['Advanced problem-solving', 'Lab concept explanations', 'Monthly mock tests', 'Study planning'],
    emoji: '📘',
  },
  '9th': {
    title: 'Class 9th',
    tagline: 'Stepping into Senior School',
    desc: 'Class 9 marks the entry into senior secondary. We focus on thorough NCERT coverage and building exam temperament early.',
    subjects: ['Mathematics', 'Physics', 'Chemistry', 'Biology', 'English', 'SST'],
    highlights: ['NCERT mastery', 'Previous year papers', 'Bi-weekly tests', 'Board exam orientation'],
    emoji: '🚀',
  },
  '10th': {
    title: 'Class 10th',
    tagline: 'Board Exam Excellence',
    desc: 'The most crucial year. Our intensive board exam preparation program has a 95%+ success rate with many students scoring distinction.',
    subjects: ['Mathematics', 'Science', 'Social Science', 'English', 'Hindi/Sanskrit'],
    highlights: ['Full board syllabus coverage', 'Mock board exams', 'Answer writing techniques', 'Last-minute revision strategy'],
    emoji: '🏆',
  },
  '11th': {
    title: 'Class 11th',
    tagline: 'Choosing Your Stream',
    desc: 'Class 11 is the foundation for Class 12 and entrance exams. We offer comprehensive coaching for Science, Commerce, and Arts streams.',
    subjects: ['Physics', 'Chemistry', 'Mathematics/Biology', 'Accountancy', 'Economics', 'Business Studies', 'English'],
    highlights: ['Stream-specific curriculum', 'JEE/NEET foundation (Science)', 'CA foundation support (Commerce)', 'Intensive concept building'],
    emoji: '🔬',
  },
  '12th': {
    title: 'Class 12th',
    tagline: 'Achieving Your Dreams',
    desc: 'The final milestone. Our Class 12 program is designed for board excellence AND competitive entrance exam preparation simultaneously.',
    subjects: ['Physics', 'Chemistry', 'Mathematics/Biology', 'Accountancy', 'Economics', 'English'],
    highlights: ['Dual preparation: Boards + Entrance', 'Chapter-wise revision modules', 'Full-length mock tests', 'College counselling'],
    emoji: '🎓',
  },
};

export async function generateStaticParams() {
  return Object.keys(gradeData).map(grade => ({ grade }));
}

export function generateMetadata({ params }) {
  const data = gradeData[params.grade];
  return {
    title: data ? `${data.title} Coaching | Gurukul Eduworld` : 'Class | Gurukul Eduworld',
    description: data?.desc,
  };
}

export default function ClassPage({ params }) {
  const data = gradeData[params.grade];
  if (!data) return notFound();

  return (
    <>
      <Navbar />
      <main>
        <section className={styles.hero}>
          <div className="container">
            <div className={styles.heroEmoji}>{data.emoji}</div>
            <h1>{data.title}</h1>
            <p className={styles.tagline}>{data.tagline}</p>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <div className={styles.grid}>
              <div>
                <h2 className="section-title">About This Program</h2>
                <p style={{ color: 'var(--text-muted)', lineHeight: '1.8', marginBottom: '32px' }}>{data.desc}</p>

                <h3 className={styles.subHeading}>Subjects Covered</h3>
                <div className={styles.subjectTags}>
                  {data.subjects.map((s, i) => (
                    <span key={i} className={styles.tag}>{s}</span>
                  ))}
                </div>

                <h3 className={styles.subHeading} style={{ marginTop: '28px' }}>Program Highlights</h3>
                <ul className={styles.highlights}>
                  {data.highlights.map((h, i) => (
                    <li key={i}>✅ {h}</li>
                  ))}
                </ul>
              </div>

              <div className={styles.sidebar}>
                <div className={styles.sideCard}>
                  <h3>Ready to Enroll?</h3>
                  <p>Join hundreds of students who are already excelling in {data.title} with our guidance.</p>
                  <a href="/about#contact" className="btn-primary" style={{ width: '100%', textAlign: 'center', display: 'block' }}>
                    Enquire Now
                  </a>
                  <div className={styles.sideInfo}>
                    <p>📞 +91 98765 43210</p>
                    <p>✉️ info@gurukuleduworld.com</p>
                    <p>🕐 Mon–Sat: 7 AM – 8 PM</p>
                  </div>
                </div>

                <div className={styles.statsCard}>
                  <div className={styles.statItem}>
                    <strong>95%+</strong>
                    <span>Success Rate</span>
                  </div>
                  <div className={styles.statItem}>
                    <strong>15-20</strong>
                    <span>Students/Batch</span>
                  </div>
                  <div className={styles.statItem}>
                    <strong>Free</strong>
                    <span>Trial Class</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <ContactSection />
      </main>
      <Footer />
    </>
  );
}