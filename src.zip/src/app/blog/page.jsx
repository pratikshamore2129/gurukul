import Navbar from '../../components/Navbar';
import Footer from '../../components/Footer';
import styles from '../../styles/Blog.module.css';

export const metadata = {
  title: 'Blog | Gurukul Eduworld',
  description: 'Educational tips, study strategies, and academic insights from Gurukul Eduworld.',
};

const posts = [
  { title: 'Top 10 Study Tips for Class 10 Board Exams', category: 'Exam Prep', date: 'Mar 15, 2024', emoji: '📝', excerpt: 'Preparing for board exams can feel overwhelming. Here are our top strategies that have helped thousands of students score 90%+.' },
  { title: 'How to Choose the Right Stream After Class 10', category: 'Career Guidance', date: 'Mar 8, 2024', emoji: '🔭', excerpt: 'Science, Commerce, or Arts? This comprehensive guide helps you make an informed decision based on your interests and strengths.' },
  { title: 'Mathematics Made Easy: Formulas You Must Know', category: 'Mathematics', date: 'Feb 28, 2024', emoji: '📐', excerpt: 'A curated list of essential maths formulas for classes 9–12, organized by chapter for quick revision before exams.' },
  { title: 'The Power of Revision: Why and How to Revise Effectively', category: 'Study Skills', date: 'Feb 20, 2024', emoji: '🔄', excerpt: 'Revision is not just re-reading. Learn the science-backed spaced repetition technique that top students use.' },
  { title: 'Understanding NCERT: The Foundation of Board Exams', category: 'Exam Prep', date: 'Feb 10, 2024', emoji: '📚', excerpt: 'Why NCERT books are the most important resource for board exams and how to extract maximum value from them.' },
  { title: 'Time Management for Students: A Practical Guide', category: 'Study Skills', date: 'Feb 1, 2024', emoji: '⏰', excerpt: 'Learn how to create an effective study timetable that balances academics, extracurriculars, and rest for optimal performance.' },
];

const categories = ['All', 'Exam Prep', 'Study Skills', 'Mathematics', 'Career Guidance'];

export default function BlogPage() {
  return (
    <>
      <Navbar />
      <main>
        <section className={styles.hero}>
          <div className="container">
            <h1>Educational Blog</h1>
            <p>Tips, strategies, and insights to help you excel academically</p>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <div className={styles.categories}>
              {categories.map(c => (
                <button key={c} className={`${styles.catBtn} ${c === 'All' ? styles.active : ''}`}>
                  {c}
                </button>
              ))}
            </div>
            <div className={styles.grid}>
              {posts.map((p, i) => (
                <article key={i} className={styles.card}>
                  <div className={styles.cardImage}>{p.emoji}</div>
                  <div className={styles.cardBody}>
                    <div className={styles.cardMeta}>
                      <span className={styles.cardCategory}>{p.category}</span>
                      <span className={styles.cardDate}>{p.date}</span>
                    </div>
                    <h2 className={styles.cardTitle}>{p.title}</h2>
                    <p className={styles.cardExcerpt}>{p.excerpt}</p>
                    <a href="#" className={styles.readMore}>Read More →</a>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}