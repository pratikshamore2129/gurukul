import Navbar from '../../components/Navbar';
import Footer from '../../components/Footer';
import ContactSection from '../../components/ContactSection';
import styles from '../../styles/About.module.css';

export const metadata = {
  title: 'About Us | Gurukul Eduworld',
  description: 'Learn about our mission, team, and values at Gurukul Eduworld.',
};

const team = [
  { name: 'Dr. Ramesh Sharma', role: 'Founder & Director', subject: 'Mathematics', initials: 'RS', exp: '20+ years' },
  { name: 'Mrs. Sunita Patel', role: 'Academic Head', subject: 'Science', initials: 'SP', exp: '15+ years' },
  { name: 'Mr. Arjun Mehta', role: 'Senior Faculty', subject: 'Physics', initials: 'AM', exp: '12+ years' },
  { name: 'Ms. Priya Joshi', role: 'Faculty', subject: 'Chemistry', initials: 'PJ', exp: '10+ years' },
  { name: 'Mr. Ravi Kumar', role: 'Faculty', subject: 'English & SST', initials: 'RK', exp: '8+ years' },
  { name: 'Mrs. Anita Singh', role: 'Faculty', subject: 'Biology', initials: 'AS', exp: '11+ years' },
];

const values = [
  { icon: '🎯', title: 'Excellence', desc: 'We set high standards and strive for the best outcomes for every student.' },
  { icon: '🤝', title: 'Integrity', desc: 'Honest, transparent, and ethical in all our academic and administrative practices.' },
  { icon: '💡', title: 'Innovation', desc: 'Modern teaching methods combined with proven academic strategies.' },
  { icon: '❤️', title: 'Care', desc: 'Personal attention and emotional support to every student in our family.' },
];

export default function AboutPage() {
  return (
    <>
      <Navbar />
      <main>
        {/* Hero */}
        <section className={styles.hero}>
          <div className="container">
            <h1>About Gurukul Eduworld</h1>
            <p>Our mission, our team, our values — all in service of your success.</p>
          </div>
        </section>

        {/* Mission */}
        <section className="section">
          <div className="container">
            <div className={styles.missionGrid}>
              <div>
                <h2 className="section-title">Our Mission</h2>
                <p style={{ color: 'var(--text-muted)', lineHeight: '1.8', marginBottom: '16px' }}>
                  At Gurukul Eduworld, we believe every child deserves access to quality education that 
                  builds not just academic knowledge, but critical thinking, confidence, and character.
                </p>
                <p style={{ color: 'var(--text-muted)', lineHeight: '1.8' }}>
                  Founded in 2010, we have been guiding students from grades 7 through 12 across all 
                  streams — Science, Commerce, and Arts — helping them excel in board exams and competitive 
                  entrance tests.
                </p>
              </div>
              <div className={styles.missionImageBox}>📖</div>
            </div>
          </div>
        </section>

        {/* Values */}
        <section className={`section ${styles.valuesSection}`}>
          <div className="container">
            <h2 className="section-title" style={{ textAlign: 'center' }}>Our Core Values</h2>
            <p className="section-subtitle" style={{ textAlign: 'center' }}>What drives us every single day</p>
            <div className={styles.valuesGrid}>
              {values.map((v, i) => (
                <div key={i} className={styles.valueCard}>
                  <div className={styles.valueIcon}>{v.icon}</div>
                  <h3>{v.title}</h3>
                  <p>{v.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Team */}
        <section className="section">
          <div className="container">
            <h2 className="section-title" style={{ textAlign: 'center' }}>Meet Our Faculty</h2>
            <p className="section-subtitle" style={{ textAlign: 'center' }}>Experienced educators dedicated to your growth</p>
            <div className={styles.teamGrid}>
              {team.map((m, i) => (
                <div key={i} className={styles.teamCard}>
                  <div className={styles.teamAvatar}>{m.initials}</div>
                  <h3>{m.name}</h3>
                  <span className={styles.teamRole}>{m.role}</span>
                  <p className={styles.teamSubject}>{m.subject}</p>
                  <p className={styles.teamExp}>Experience: {m.exp}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <ContactSection />
      </main>
      <Footer />
    </>
  );
}